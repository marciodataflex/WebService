<?php

  $xml = simplexml_load_file("http://www.rafaelwendel.com/ws/index.php?id=2");
  print_r($xml);

?>
