<?php
  mysql_connect('localhost','usuario','senha') or die('Erro ao conectar com o servidor');
  mysql_select_db('nome_do_banco') or die ('Erro ao selecionar o banco de dados');
?>
