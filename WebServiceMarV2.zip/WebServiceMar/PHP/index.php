<?php
  require_once('xmlclass.php');
  require_once('config.php');

  $xml= new Xml();

  $erro = 0;

  $idproduto = $_GET['id'];

  $xml->openTag("response");

  if($idproduto == ''){
    $erro =1;
    $msgerro = 'Código Inválido';
  }
  else{
    $rs = mysql_query("select * from produto where idproduto = $idproduto");
    if(mysql_num_rows($rs) > 0){
      $reg = mysql_fetch_object($rs);
      $xml->addTag('nome_produto',$reg->nome_produto);
      $xml->addTag('valor',$reg->valor);
    }
    else{
      $erro = 2;
      $msgerro = 'Produto não encontrado!';
    }
    $xml->addTag('erro', $erro);
    $xml->addTag('msgerro', $msgerro);

    $xml->closeTag("response");

    echo $xml;
