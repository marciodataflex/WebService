<?php

  class xml {

    private $xml;
    private $tab = 1;

    public function _construct($version='1.0', $encode = 'UFT-8') {
      $this->xml .="<?xml version='$version' encoding='$encode' ?>\n";
    }

    public function openTag($name){
      $this->addTab();
      $this->xml .="<$name>\n";
      $this->tab++;
    }

    public function closeTag($name){
      $this->tab--;

      $this->xml .="</$name>\n";
    }

    public function setValue ($value){
      $this-> .="$value\n";
    }

    private  function addTab(){
      for ($i = 1; $i <= $this->tab; $i++){
        $this->xml .= "\t";
      }
    }

    public function addTag($name, $value){
      $this->addTab();
      $this ->xml .="<$name>$value</$name>\n";
    }

    function _toString(){
      return $this->sml;
    }

  }





 ?>
