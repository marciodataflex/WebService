<?php

  $xml = simplexml_load_file("localhost:8080/index.php?num_cartao_cns=185971");
  print_r($xml);

?>
