<?php
  require_once('xmlclass.php');
  require_once('config.php');

  $xml= new Xml();

  $erro = 0;

  $num_cartao_cns = $_GET['num_cartao_cns'];

  $xml->openTag("response");

  if($num_sus == ''){
    $erro =1;
    $msgerro = 'Numero de cartao SUS inválido !';
  }
  else{
    $rs = mysql_query("select * from produto where num_cartao_cns = $num_cartao_cns");
    if(mysql_num_rows($rs) > 0){
      $reg = mysql_fetch_object($rs);
      $xml->addTag('num_cartao_cns',$reg->num_cartao_cns);
      $xml->addTag('cpf',$reg->cpf);
      $xml->addTag('nome_usuario',$reg->nome_usuario);
    }
    else{
      $erro = 2;
      $msgerro = 'Produto não encontrado!';
    }
    $xml->addTag('erro', $erro);
    $xml->addTag('msgerro', $msgerro);
    $xml->closeTag("response");
    echo $xml;
  }
?>
