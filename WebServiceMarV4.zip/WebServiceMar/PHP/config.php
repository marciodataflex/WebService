<?php
  mysqli_connect('localhost','root','metallica','sus') or die('Erro ao conectar com o servidor');
  //mysqli_select_db('sus') or die ('Erro ao selecionar o banco de dados');
?>
