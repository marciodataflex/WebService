<?php

  echo "passo1";
  $xml = simplexml_load_file("http://localhost:8080/index.php");
  print_r($xml);

?>
