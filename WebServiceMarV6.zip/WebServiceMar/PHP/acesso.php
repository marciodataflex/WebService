<?php

  $xml = simplexml_load_file("http://localhost:80/index.php");
  print_r($xml);

?>
