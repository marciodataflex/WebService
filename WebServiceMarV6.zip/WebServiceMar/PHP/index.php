<?php
  require_once('Xml.Class.php');
  require_once('config.php');

  $xml= new Xml();

  $erro = 0;
  $msgerro = '';

  //$num_cartao_cns = "185971";
  //$num_cartao_cns = '';

  $num_cartao_cns = $_GET['numCNS'];

  $xml->openTag("response");

  if($num_cartao_cns == ""){
    $erro =1;
    $msgerro = "Numero de cartao SUS inválido !";
  }
  else{
    $rs = mysqli_query($conexao,"select * from paciente where num_cartao_cns = $num_cartao_cns");
    if(mysqli_num_rows($rs) > 0){
      $reg = mysqli_fetch_object($rs);
      $xml->addTag('num_cartao_cns',$reg->num_cartao_cns);
      $xml->addTag('cpf',$reg->cpf);
      $xml->addTag('nome_usuario',$reg->nome_paciente);
    }
    else{
      $erro = 2;
      $msgerro = "Paciente não encontrado!";
    }
  }
  $xml->addTag('erro', $erro);
  $xml->addTag('msgerro', $msgerro);
  $xml->closeTag("response");
  echo $xml;
?>
