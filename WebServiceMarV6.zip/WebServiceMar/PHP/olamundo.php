<?php
  $primeiro='hello world';
  echo $primeiro;
  echo "Estou aqui!!";


 ?>
