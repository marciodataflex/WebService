<?php
  //$primeiro="&lt;h2&gt;hello world<cr>";
  //$primeiro.="estou aqui!!!</h2>";
  //echo $primeiro
  $xml = simplexml_load_file("paciente.xml");
  print_r($xml);
?>
