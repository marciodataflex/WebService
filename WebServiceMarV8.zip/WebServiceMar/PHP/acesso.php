<?php

  $numCNS=$_GET['numCNS'];
  $xml = simplexml_load_file("http://localhost:8080/index.php?numCNS=$numCNS");
  //$xml = simplexml_load_file("paciente.xml");
  print_r($xml);

?>
