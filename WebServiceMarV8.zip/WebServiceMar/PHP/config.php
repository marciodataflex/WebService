<?php
  $conexao = mysqli_connect('localhost','root','','sus') or die('Erro ao conectar com o servidor');
?>
