<?php
  require_once('Xml.Class.php');
  require_once('config.php');

  $xml= new Xml();

  $erro = 0;
  $msgerro = '';

  $num_cartao_cns = $_GET['numCNS'];

  $xml->openTag("response");

  if($num_cartao_cns == ""){
    $erro =1;
    $msgerro = "Numero de cartao SUS inválido !";
  }
  else{
    $rs = mysqli_query($conexao,"select * from paciente where num_cartao_cns = $num_cartao_cns");
    if(mysqli_num_rows($rs) > 0){
      $reg = mysqli_fetch_object($rs);
      $xml->addTag('num_cartao_cns',$reg->num_cartao_cns);
      $xml->addTag('cpf',$reg->cpf);
      $xml->addTag('rg',$reg->rg);
      $xml->addTag('nome_mae',$reg->nome_mae);
      $xml->addTag('endereco',$reg->endereco);
      $xml->addTag('sobrenome_paciente',$reg->sobrenome_paciente);
      $xml->addTag('nome_paciente',$reg->nome_paciente);
      $xml->addTag('telefone',$reg->telefone);
      $xml->addTag('numero',$reg->numero);
      $xml->addTag('cep',$reg->cep);
      $xml->addTag('data_nasc',$reg->data_nasc);
    }
    else{
      $erro = 2;
      $msgerro = "Paciente não encontrado!";
    }
  }
  $xml->addTag('erro', $erro);
  $xml->addTag('msgerro', $msgerro);
  $xml->closeTag("response");
  echo $xml;
  $arquivo = fopen('C:\Users\Marcio\Desktop\WebServiceMar\PHP\paciente.xml','w+');
  fwrite ($arquivo,$xml);
  fclose($arquivo);
?>
